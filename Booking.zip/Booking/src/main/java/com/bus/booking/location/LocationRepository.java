package com.bus.booking.location;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<location, Integer> {
    
    //location findByschID(int schID);
}
