
/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.locationlist;


import java.util.List;

import com.bus.booking.user.User;


/**
 * Interface for User Service
 */
public interface LocationlistService {

    /**
     * Method to register a user
     * @param user
     */
	 int register(Locationlist locationlist);

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return userID
     */
    

    /**
     * Method to update a user
     * @param user
     * @return 
     */
    boolean update(Locationlist locationlist);

    /**
     * Method to get a user by ID
     * @param userID
     * @return User
     */
    Locationlist getlocation(int id);

    /**
     * Method to get all users
     * @return List<User>
     */
    List<Locationlist> getAlllocations();

    /**
     * Method to delete a user
     * @param userID
     * @return
     */
    boolean delete(int id);

}
