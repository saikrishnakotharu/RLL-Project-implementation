package com.bus.booking.location;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocationServiceImpl implements LocationService {

    @Autowired
    private LocationRepository locationRepository;

    @Override
    public int register(location location) {
        location savedLocation = locationRepository.save(location);
        return savedLocation.getId();
    }

    @Override
    public location getlocation(int id) {
        return locationRepository.findById(id).orElse(null);
    }

    @Override
    public List<location> getAlllocations() {
        return locationRepository.findAll();
    }

    @Override
    public boolean update(location locationNew) {
        location locationOld = locationRepository.findById(locationNew.getId()).orElse(null);
        if (locationOld != null) {
            locationOld.setId(locationNew.getId());
            locationOld.setFromlocation(locationNew.getFromlocation());
            locationOld.setTolocation(locationNew.getTolocation());
            locationOld.setDeparturedate(locationNew.getDeparturedate());
            locationOld.setDeparturetime(locationNew.getDeparturetime());
            locationOld.setEtadate(locationNew.getEtadate());
            locationOld.setEtatime(locationNew.getEtatime());
            locationOld.setAvaliability(locationNew.getAvaliability());
            locationOld.setPrice(locationNew.getPrice());

            locationRepository.save(locationOld);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(int id) {
        location location = locationRepository.findById(id).orElse(null);
        if (location != null) {
            locationRepository.delete(location);
            return true;
        }
        return false;
    }
}
