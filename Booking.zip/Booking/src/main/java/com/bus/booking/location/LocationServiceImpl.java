/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service implementation for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.location;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;


/**
 * Implementation for User Service
 */
@Repository
public class LocationServiceImpl implements LocationService {   

    /**
     * Autowired UserRepository
     */
    @Autowired
    private LocationRepository locationRepository;

    /**
     * Method to register a user
     * @param user
     */
    
   

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return
     */
   

    /**
     * Method to return a user
     * @param user
     * @return
     */
    @Override
    public Location getlocation(int id) {
        return LocationRepository.findById(id).orElse(null);        
    }

    /**
     * Method to get all users
     * @return List<User>
     */
    @Override
    public List<location> getAlllocations(){
        return locationRepository.findAll();
    }

    /**
     * Method to update a user
     * @param userID
     * @return
     */
    @Override
    public boolean update(location locationNew) {
        location locationOld = ; locationRepository.findByBus_id(locationNew.getstd_id()).orElse(null);
        if (locationOld != null) {
            locationOld.setsch_id(sch_idNew.getBusNo());
            locationOld.setDate(DateNew.getDate());
            locationOld.setBusName(BusNameNew.getBusName());
            locationOld.setlocation(locationNew.getlocation());
            locationOld.setDepartures(DeparturesNew.getDepartures());
            locationOld.setETA(ETANew.getETA());
            locationOld.setAvaliability(AvaliabilityNew.getAvaliability());
            locationOld.setPrice(PriceNew.getPrice());
            locationOld.setAction(ActionNew.getAction());
            locationRepository.save(locationOld);
            return true;
        }
        return false;
    }

    /**
     * Method to delete a user by ID
     * @param userID
     * @return
     */
    @Override
    public boolean delete(int id) {
        User user = locationRepository.findById(id).orElse(null);
        if (user != null) {
            userRepository.delete(user);
            return true;
        }
        return false;
    }

	@Override
	public location getlocation(int schID) {
		// TODO Auto-generated method stub
		return null;
	}
}
