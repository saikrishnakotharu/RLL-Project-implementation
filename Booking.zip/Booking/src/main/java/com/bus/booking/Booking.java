package com.bus.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Booking {

	public static void main(String[] args) {
		SpringApplication.run(Booking.class, args);
		System.out.println("Started...");
	}

}
