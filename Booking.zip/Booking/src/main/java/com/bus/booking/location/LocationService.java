/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.location;


import java.util.List;


/**
 * Interface for User Service
 */
public interface LocationService {

    /**
     * Method to register a user
     * @param user
     */
 

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return userID
     */
    

    /**
     * Method to update a user
     * @param user
     * @return 
     */
    boolean update(location location);

    /**
     * Method to get a user by ID
     * @param userID
     * @return User
     */
    location getlocation(int id);

    /**
     * Method to get all users
     * @return List<User>
     */
    List<location> getAlllocations();

    /**
     * Method to delete a user
     * @param userID
     * @return
     */
    boolean delete(int id);

}
