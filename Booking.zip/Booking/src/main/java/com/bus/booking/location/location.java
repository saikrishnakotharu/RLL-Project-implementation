package com.bus.booking.location;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class location {
	
	    @Id
	    @GeneratedValue
	    @Column(name = "sch_id")
	    private int id;

		@Column(length = 20)
	    private int Date;
	    
	    @Column(length = 20)
	    private String BusName;
	    
	    @Column(length = 20)
	    private String from;
	    
	    @Column(length = 20)
	    private String to;
	    
	    @Column(length = 20)
	    private int Departuresfrom;
	    
	    @Column(length = 20)
	    private int Departuresto;
	    
	    @Column(length = 20)
	    private String ETAfrom;
	    
	    @Column(length = 20)
	    private int ETAto;
	    
	    @Column(length = 20)
	    private int Avaliability;
	    
	    @Column(length = 20)
	    private int Price;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getDate() {
			return Date;
		}

		public void setDate(int date) {
			Date = date;
		}

		public String getBusName() {
			return BusName;
		}

		public void setBusName(String busName) {
			BusName = busName;
		}

		public String getFrom() {
			return from;
		}

		public void setFrom(String from) {
			this.from = from;
		}

		public String getTo() {
			return to;
		}

		public void setTo(String to) {
			this.to = to;
		}

		public int getDeparturesfrom() {
			return Departuresfrom;
		}

		public void setDeparturesfrom(int departuresfrom) {
			Departuresfrom = departuresfrom;
		}

		public int getDeparturesto() {
			return Departuresto;
		}

		public void setDeparturesto(int departuresto) {
			Departuresto = departuresto;
		}

		public String getETAfrom() {
			return ETAfrom;
		}

		public void setETAfrom(String eTAfrom) {
			ETAfrom = eTAfrom;
		}

		public int getETAto() {
			return ETAto;
		}

		public void setETAto(int eTAto) {
			ETAto = eTAto;
		}

		public int getAvaliability() {
			return Avaliability;
		}

		public void setAvaliability(int avaliability) {
			Avaliability = avaliability;
		}

		public int getPrice() {
			return Price;
		}

		public void setPrice(int price) {
			Price = price;
		}

		public location(int id, int date, String busName, String from, String to, int departuresfrom, int departuresto,
				String eTAfrom, int eTAto, int avaliability, int price) {
			super();
			this.id = id;
			Date = date;
			BusName = busName;
			this.from = from;
			this.to = to;
			Departuresfrom = departuresfrom;
			Departuresto = departuresto;
			ETAfrom = eTAfrom;
			ETAto = eTAto;
			Avaliability = avaliability;
			Price = price;
		}

		public location() {
			super();
		}
	    
	    
	    
	    

		
	  
	   

		

	    

	    
	}

