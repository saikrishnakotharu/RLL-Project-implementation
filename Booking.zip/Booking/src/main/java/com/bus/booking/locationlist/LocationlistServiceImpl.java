/**
 * Module: Location List Module
 * Aim: To provide the service implementation for location list
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.locationlist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service; // Change to Service annotation

import java.util.List;

@Service // Change to Service annotation
public class LocationlistServiceImpl implements LocationlistService {

    @Autowired
    private LocationlistRepository locationlistRepository; // Change variable name

    @Override
    public int register(Locationlist locationlist) {
        Locationlist savedLocationlist = locationlistRepository.save(locationlist); // Use locationlistRepository to save
        return savedLocationlist.getId(); // Return the saved location's ID
    }

    public Locationlist getLocationlist(int id) { // Correct method signature
        return locationlistRepository.findById(id).orElse(null);
    }

    @Override
    public List<Locationlist> getAlllocations() {
        return locationlistRepository.findAll(); // Use locationlistRepository to retrieve all locations
    }

    @Override
    public boolean update(Locationlist locationlistNew) {
        Locationlist locationlistOld = locationlistRepository.findById(locationlistNew.getId()).orElse(null);
        if (locationlistOld != null) {
            locationlistOld.setTerminal(locationlistNew.getTerminal());
            locationlistOld.setCity(locationlistNew.getCity());
            locationlistOld.setProvince(locationlistNew.getProvince());
            locationlistRepository.save(locationlistOld); // Save the updated location
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(int id) {
        Locationlist locationlist = locationlistRepository.findById(id).orElse(null);
        if (locationlist != null) {
            locationlistRepository.delete(locationlist); // Use locationlistRepository to delete
            return true;
        }
        return false;
    }

	@Override
	public Locationlist getlocation(int id) {
		 return locationlistRepository.findById(id).orElse(null);       
	}
}
