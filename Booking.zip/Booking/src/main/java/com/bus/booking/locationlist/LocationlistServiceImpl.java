/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service implementation for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.locationlist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;


/**
 * Implementation for User Service
 */
@Repository
public abstract class LocationlistServiceImpl implements LocationlistService {   

    /**
     * Autowired UserRepository
     */
    @Autowired
    private LocationlistRepository locationRepository;

    /**
     * Method to register a user
     * @param user
     */
    
   

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return
     */
   

    /**
     * Method to return a user
     * @param user
     * @return
     */
    @Override
    public Locationlist getLocationlist(int id) {
        return LocationlistRepository.findById(id).orElse(null);        
    }

    /**
     * Method to get all users
     * @return List<User>
     */
    @Override
    public List<locationlist> getAlllocations(){
        return locationlistRepository.findAll();
    }

    /**
     * Method to update a user
     * @param userID
     * @return
     */
    @Override
    public boolean update(Locationlist LocationlistNew) {
        Locationlist LocationlistOld = . LocationlistRepository.findByid(LocationlistNew.getid()).orElse(null);
        if (LocationlistOld != null) {
            LocationlistOld.setid(idNew.getid());
            LocationlistOld.setterminal(terminalNew.getTerminal());
			LocationlistOld.setcity(cityNew.getcity());
			LocationlistOld.setprovince(provinceNew.getprovince());
            return true;
        }
        return false;
    }

    /**
     * Method to delete a user by ID
     * @param userID
     * @return
     */
    @Override
    public boolean delete(int id) {
        User user = locationRepository.findById(id).orElse(null);
        if (user != null) {
            userRepository.delete(user);
            return true;
        }
        return false;
    }

	@Override
	public location getlocation(int schID) {
		// TODO Auto-generated method stub
		return null;
	}
}
