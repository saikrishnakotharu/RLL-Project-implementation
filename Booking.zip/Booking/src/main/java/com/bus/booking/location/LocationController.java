/**
 * Module: User Module
 * Aim: To provide the user related services as RESTful APIs
 * Services: USER REGISTRATION, USER LOGIN, GET USER BY ID, UPDATE USER, DELETE USER, BOOK RIDE, CANCEL RIDE, REVIEW RIDE
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.location;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * Rest Controller for User Module
 * CrossOrigin annotation is used to allow cross origin requests
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LocationController {
    
    /**
     * Autowiring the user service
     */
    @Autowired
    private LocationService LocationService;

    /**
     * Method to register a user
     * @param user
     * @return userID
     */
   

    /**
     * Method to login a user
     * @param user
     * @return userID
     */
   
    
    /**
     * Method to get user by ID
     * @param userID
     * @return user
     */
    @GetMapping(value="/user/get/{schID}", produces="application/json")
    public location getLocationByBusNo(@PathVariable int schID) {
        return LocationService.getlocation(schID);
    }
    
    /**
     * Method to get all user
     * @return List<User>
     */
    @GetMapping(value="/user/listAll", produces="application/json")
    public List<location> getAllLocation() {
        return LocationService.getAlllocations();
    }

    /**
     * Method to update user
     * @param user
     * @return
     */
    @PutMapping(value="/user/update", consumes="application/json")
    public boolean updateLocation(@RequestBody location location) {
        return LocationService.update(location);
    }

    /**
     * Method to delete user
     * @param userID
     * @return
     */
    @DeleteMapping(value="/user/delete/{userID}")
    public boolean deleteLocation(@PathVariable int BusNo) {
        return LocationService.delete(BusNo);
    }    
}
